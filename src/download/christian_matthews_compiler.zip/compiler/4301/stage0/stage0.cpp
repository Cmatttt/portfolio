/*
Zachary German & Christian Matthews
CS 4301
Compiler Stage 0
*/

#include "stage0.h"
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <queue>
#include <sstream>
#include <stack>
#include <string>
#include <vector>

/////////////// Variables /////////////////
const string keywordList[] = {"program","begin","end","var","const","integer","boolean","true","false","not"};
const char specSymList[] = {'=',':',',',';','.','+','-'};
const char alphaList[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
const char numsList[] = {'1','2','3','4','5','6','7','8','9','0'};
const char alphaNumsList[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0','_'};
// ALPHANUMS = alpha[] + nums[] + '_'

Compiler::Compiler(char **argv) // constructor
{
    std::ifstream sourceFile;
    sourceFile.open(argv[1]);
    std::ofstream listingFile;
    listingFile.open(argv[2]);
    std::ofstream objectFile;
    objectFile.open(argv[3]);
}

Compiler::~Compiler()           // destructor
{
    sourceFile.close();
    listingFile.close();
    objectFile.close();
}

void Compiler::createListingHeader()
{
    time_t now = time (NULL);
    listingFile << "STAGE0: Zachary German & Cristian Matthews      "
         << ctime(&now) << "\n\nLINE NO.             SOURCE STATEMENT\n\n";
}

void Compiler::parser()///////////////////
{
    nextChar();
    //ch must be initialized to the first character of the source file
    if (nextToken() != "program"){
        processError("keyword \"program\" expected");
    }
    //a call to nextToken() has two effects
    //  (1) the variable, token, is assigned the value of the next token
    //  (2) the next token is read from the source file in order to make
    //      the assignment. The value returned by nextToken() is also
    //      the next token.
    prog();
    //parser implements the grammar rules, calling first rule
}

void Compiler::createListingTrailer()
{
    cout << "COMPILATION TERMINATED,"; ///////////////////////////<< "# ERRORS ENCOUNTERED"
}

// Methods implementing the grammar productions

void Compiler::prog() //token should be "program"          // stage 0, production 1
{
    if (token != "program"){
        processError("keyword \"program\" expected");
    }
    progStmt();
    if (token == "const"){
        consts();
    }
    if (token == "var"){
        vars();
    }
    if(token != "begin"){
        processError("keyword \"begin\" expected");
    }
    beginEndStmt();
    // const char casting to check for END_OF_FILE token
    if (*token.c_str() != END_OF_FILE){                          ////////////////////////////// test later if error
        processError("no text may follow \"end\"");
    }
}

void Compiler::progStmt()  //token should be "program"  // stage 0, production 2
{
    string x;
    if (token != "program"){
        processError("keyword \"program\" expected");
    }
    x = nextToken();
    if (!(isNonKeyId(token))){
        processError("program name expected");
    }
    if (nextToken() != ";"){
        processError("semicolon expected");
    }
    nextToken();
    code("program", x);
    insert(x,PROG_NAME,CONSTANT,x,NO,0);
}

void Compiler::consts()    //token should be "const"     // stage 0, production 3
{
    if (token != "const"){
        processError("keyword \"const\" expected");
    }
    if (!(isNonKeyId(nextToken()))){
        processError("non-keyword identifier must follow \"const\"");
    }
    constStmts();
}

void Compiler::vars()    //token should be "var"       // stage 0, production 4
{
    if (token != "var"){
        processError("keyword \"var\" expected");
    }
    if (!(isNonKeyId(nextToken()))){
        processError("non-keyword identifier must follow \"var\"");
    }
    varStmts();
}

void Compiler::beginEndStmt()  //token should be "begin"       // stage 0, production 5
{
    if (token != "begin"){
        processError("keyword \"begin\" expected");
    }
    if (nextToken() != "end"){
        processError("keyword \"end\" expected");
    }
    if (nextToken() != "."){
        processError("period expected");
    }
    nextToken();
    code("end", ".");
}

void Compiler::constStmts()   //token should be NON_KEY_ID  // stage 0, production 6
{
    string x,y;
    if (!(isNonKeyId(token))){
        processError("non-keyword identifier expected");
    }
    x = token;
    if (nextToken() != "="){
        processError("\"=\" expected");
    }
    y = nextToken();
    if (y != "+" && y != "-" && y != "not"
        && !isNonKeyId(y) && !isBoolean(y) && !isInteger(y)){

        processError("token to right of \"=\" illegal");
    }
    if (y == "+" || y == "-"){
        if (!(isInteger(nextToken()))){
            processError("integer expected after sign");
        }
        y = y + token;
    }
    if (y == "not"){
        if (!(isBoolean(nextToken()))){
            processError("boolean expected after \"not\"");
        }
        if (token == "true"){
            y = "false";
        }
        else{
            y = "true";
        }
    }
    if (nextToken() != ";"){
        processError("semicolon expected");
    }
    if (whichType(y) != INTEGER && whichType(y) != BOOLEAN){
        processError("data type of token on the right-hand side must be INTEGER or BOOLEAN");
    }
    insert(x,whichType(y),CONSTANT,whichValue(y),YES,1);
    x = nextToken();
    if (y != "begin" && y != "var" && !(isNonKeyId(y))){
        processError("non-keyword identifier, \"begin\", or \"var\" expected");
    }
    if (isNonKeyId(x)){
        constStmts();
    }
}

void Compiler::varStmts()  //token should be NON_KEY_ID     // stage 0, production 7
{
    string x,y;
    if (!(isNonKeyId(token))){
        processError("non-keyword identifier expected");
    }
    x = ids();
    if (token != ":"){
        processError("\":\" expected");
    }
    if (nextToken() != "integer" && token != "boolean"){
        processError("illegal type follows \":\"");
    }
    y = token;
    if (nextToken() != ";"){
        processError("semicolon expected");
    }
    insert(x,whichType(y),VARIABLE,"",YES,1); ///////////////////// changed y to whichType(y)
    if (nextToken() != "begin" && !(isNonKeyId(token))){
        processError("non-keyword identifier or \"begin\" expected");
    }
    if (isNonKeyId(token)){
        varStmts();
    }
}

string Compiler::ids()    //token should be NON_KEY_ID      // stage 0, production 8
{
    string temp,tempString;
    if (!(isNonKeyId(token))){
        processError("non-keyword identifier expected");
    }
    tempString = token;
    temp = token;
    if (nextToken() == ","){
        if (!(isNonKeyId(nextToken()))){
            processError("non-keyword identifier expected");
        }
        tempString = temp + "," + ids();
    }
    return tempString;
}

// Helper functions for the Pascallite lexicon

bool Compiler::isKeyword(string s) const  // determines if s is a keyword
{
    for (string keyword : keywordList){
        if (keyword == s){
            return true;
        }
    }
    return false;
}

bool Compiler::isSpecialSymbol(char c) const // determines if c is a special symbol
{
    for (char specSym : specSymList){
        if (specSym == c){
            return true;
        }
    }
    return false;
}

bool Compiler::isNonKeyId(string s) const // determines if s is a non_key_id
{
    bool startsWithAlpha = 0;
    for (string::size_type i = 0; i < s.size(); i++){
        //Does it start with a lowercase letter?
        if (i == 0){
            for (char alpha : alphaList){
                if (s[i] == alpha){
                    startsWithAlpha = 1;
                }
            }
            if (startsWithAlpha == 0){
                return false;
            }
        }

        //Does the rest consist of letters, numbers, and '_'?
        bool valid = 0;
        for (char listChar : alphaNumsList){
            if (s[i] == listChar){
                valid = 1;
            }
        }
        if (!valid){
            return false;
        }

        //Does it end in an underscore ('_')
        if (i+1 == s.size() && s[i] == '_'){
            return false;
        }
    }
    return true;
}

bool Compiler::isInteger(string s) const  // determines if s is an integer
{
    try {stoi(s);}
    catch (const invalid_argument& ia){
        return false;
    }
    return true;
}

bool Compiler::isBoolean(string s) const  // determines if s is a boolean
{
    if (s == "true" || s == "false"){
        return true;
    }
    return false;
}

bool Compiler::isLiteral(string s) const  // determines if s is a literal
{
    // ** I used Motls syntax chart to help me with this. its on page 2 of "Pascallite Syntax Chart - Stage 0" **

    // if s is integer
    if (isInteger(s)) {
        return true;
    }

    // if s starts with "+" or "-" AND is an integer
    if ((s[0] == '+' || s[0] == '-') && isInteger(s.substr(1,(s.length()-1)))) {
        return true;
    }

    // if s is boolean
    if (isBoolean(s)) {
        return true;
    }

    // if s = "not" AND is a boolean
    if (s.substr(0,2) == "not") {
        if (isBoolean(s)) {
            return true;
        }
    }
}

// Action routines

void Compiler::insert(string externalName, storeTypes inType, modes inMode,
                      string inValue, allocation inAlloc, int inUnits)
{
    deque<string> nameList;
    int strStart = 0;
                                                                // hi,how,why
    for (int i = 0; i < externalName.length(); i++){
        if (externalName[i] == ','){
            nameList.push_back(externalName.substr(strStart,i-strStart));
            strStart = i+1;
        }
        if (i == externalName.length() - 1){
            nameList.push_back(externalName.substr(strStart)); ////////// check later (might need second arg)
        }
    }


    while (!nameList.empty()){        //?? Not sure what this is
        string name = nameList.front();
        nameList.pop_front();

        if (symbolTable.count(name)){     //returns 1 if entry with 'name' key exists, 0 otherwise
            processError("multiple name definition");
        }
        else if (isKeyword(name)){
            processError("illegal use of keyword");
        }
        else { //create table entry     
            if (isupper(name[0])){
            symbolTable[name] = SymbolTableEntry(name,inType,inMode,inValue,inAlloc,inUnits);
            }
            else {
                symbolTable[name] = SymbolTableEntry(genInternalName(inType),inType,inMode,inValue,inAlloc,inUnits);
            }
        }
    }
}

storeTypes Compiler::whichType(string name) // tells which data type a name has
{
    storeTypes dataType;
    if (isLiteral(name)){
        if (isBoolean(name)){
            return BOOLEAN;
        }
        else {
            return INTEGER;
        }
    }
    else { // name is an identifier and hopefully a constant
        if (symbolTable.count(name)){
            dataType = symbolTable[name].getDataType();
        }
        else {
            processError("reference to undefined constant");
        }
    }
    return dataType;
}

string Compiler::whichValue(string name) // tells which value a name has
{
    string value;
    if (isLiteral(name)){
        value = name;
    }
    else { //name is an identifier and hopefully a constant
        if (symbolTable.count(name) && !symbolTable[name].getValue().empty()){
            value = symbolTable[name].getValue();
        }
        else {
            processError("reference to undefined constant");
        }
    }
    return value;
}

void Compiler::code(string op, string operand1 = "", string operand2 = "")
{
    if (op == "program"){
        emitPrologue(operand1);
    }
    else if (op == "end"){
        emitEpilogue();
    }
    else {
        processError("compiler error since function code should not be called with illegal arguments");
    }
}

// Emit Functions

void Compiler::emit(string label = "", string instruction = "", 
                    string operands = "", string comment = "")
{
    objectFile << left << setw(8) << label << setw(8) << instruction << setw(24) << operands << comment << endl;
    // Turn on left justification in objectFile
    // Output label in a field of width 8
    // Output instruction in a field of width 8
    // Output the operands in a field of width 24
    // Output the comment
}

void Compiler::emitPrologue(string progName, string = "")
{
    time_t now = time (NULL);
    objectFile << "; Zachary German & Cristian Matthews      " << ctime(&now) << endl;
    objectFile << "%INCLUDE \"Along32.inc\"" << endl << "%INCLUDE \"Macros_Along.inc\"" << endl << endl;
    emit("SECTION", ".text");
    emit("global", "_start", "", "; program" + progName);
    emit("_start:");
}

void Compiler::emitEpilogue(string = "", string = "")
{
    emit("","Exit", "{0}");
    emitStorage();
}

void Compiler::emitStorage()
{
    emit("SECTION", ".data");
    for (const auto &entry : symbolTable){
        if (entry.second.getAlloc() == YES && entry.second.getMode() == CONSTANT){
            emit(entry.second.getInternalName(), "dd", entry.second.getValue());
        }
    } 
    // for those entries in the symbolTable that 
    // have an allocation of YES and a storage mode of CONSTANT
    // { call emit to output a line to objectFile }
    emit("SECTION", ".bsss");
    for (const auto &entry : symbolTable){
        if (entry.second.getAlloc() == YES && entry.second.getMode() == VARIABLE){
            emit(entry.second.getInternalName(), "resd", "1");
        }
    } 
    // for those entries in the symbolTable that
    // have an allocation of YES and a storage mode of VARIABLE
    // { call emit to output a line to objectFile }    
}

// Lexical routines

char Compiler::nextChar() // returns the next character or END_OF_FILE marker
{
    sourceFile.get(ch);
    if (sourceFile.eof()){
        ch = END_OF_FILE; // use a special char to designate end of file
    }
    // else {
    //     ch = next character;
    // }
    //print to listing file (starting new line if necessary)
    if (ch == '\n'){
        listingFile << endl;
    }
    else {
        listingFile << ch;
    }
    return ch;
}

string Compiler::nextToken() // returns the next token or END_OF_FILE marker
{
    token = "";
    while (token == ""){
        switch(ch){
            /////////////////////////////////////////////////////////////////////////////////
            case '{':                   //process comment
                                        while (nextChar() != END_OF_FILE && ch != '}'){
                                            //empty body
                                        }
                                        if (ch == END_OF_FILE){
                                            processError("unexpected end of file");
                                        }
                                        else {
                                            nextChar();
                                        }
            /////////////////////////////////////////////////////////////////////////////////
            case '}':                   processError("'}' cannot begin token");
            /////////////////////////////////////////////////////////////////////////////////
            // isspace() equivalent
            case ' ':
            case '\t':
            case '\n':
            case '\v':
            case '\f':
            case '\r':                  nextChar();
            /////////////////////////////////////////////////////////////////////////////////
            // isSpecialSymbol() equivalent
            case '=':
            case ':':
            case ',':
            case '.':
            case '+':
            case '-':                   token = ch;
                                        nextChar();
            /////////////////////////////////////////////////////////////////////////////////
            // test for g++ compiler, ignore editor errors
            // islower() equivalent
            case 'a'...'z':             token = ch;
                                        while ((isalpha(nextChar()) || isdigit(ch) || ch == '_') && ch != END_OF_FILE){
                                            token += ch;
                                        }
                                        if (ch == END_OF_FILE){
                                            processError("unexpected end of file");
                                        }
            /////////////////////////////////////////////////////////////////////////////////
            // test for g++ compiler, ignore editor errors
            // isdigit() equivalent
            case '0'...'9':             token = ch;
                                        while (isdigit(nextChar()) && ch != END_OF_FILE){
                                            token += ch;
                                        }
                                        if (ch == END_OF_FILE){
                                            processError("unexpected end of file");
                                        }
            /////////////////////////////////////////////////////////////////////////////////
            case END_OF_FILE:           token = ch;
            /////////////////////////////////////////////////////////////////////////////////
            default:                    processError("illegal symbol");
        }
    }
    return token;
}

// Other routines

string Compiler::genInternalName(storeTypes stype) const
{
    static int iCnt, bCnt, pCnt = 0;
    string name;
    if (stype == INTEGER){
        name = "I";
        name = name + to_string(iCnt);
        iCnt += 1;
    }
    else if (stype == BOOLEAN){
        name = "B";
        name = name + to_string(bCnt);
        bCnt += 1;
    }
    else if (stype == PROG_NAME){
        name = "P";
        name = name + to_string(pCnt);
        pCnt += 1;
    }
    return name;
}

void Compiler::processError(string err)
{
    // loop chars appending to array and user listingFile.write() if below doesnt work
    listingFile << err << endl;
    exit(EXIT_FAILURE);
}



// // SymbolTableEntry Constructor
// SymbolTableEntry::SymbolTableEntry(string in, storeTypes st, modes m,
//                                    string v, allocation a, int u)
// {
//     setInternalName(in)
//     setDataType(st)
//     setMode(m)
//     setValue(v)
//     setAlloc(a)
//     setUnits(u)
// }

// string SymbolTableEntry::getInternalName() const
// {
//   return internalName
// }

// storeTypes SymbolTableEntry::getDataType() const
// {
//   return dataType
// }

// modes SymbolTableEntry::getMode() const
// {
//   return mode
// }

// string SymbolTableEntry::getValue() const
// {
//   return value
// }

// allocation SymbolTableEntry::getAlloc() const
// {
//   return alloc
// }

// int SymbolTableEntry::getUnits() const
// {
//   return units
// }

// void SymbolTableEntry::setInternalName(string s)
// {
//   internalName = s
// }

// void SymbolTableEntry::setDataType(storeTypes st)
// {
//   dataType = st
// }

// void SymbolTableEntry::setMode(modes m)
// {
//   mode = m
// }

// void SymbolTableEntry::setValue(string s)
// {
//   value = s
// }

// void SymbolTableEntry::setAlloc(allocation a)
// {
//   alloc = a
// }

// void SymbolTableEntry::setUnits(int i)
// {
//   units = i
// }