// Zachary German & Christian Matthews
// CS 4301
// Compiler Stage 1

#include "stage1.h"
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <queue>
#include <sstream>
#include <stack>
#include <string>
#include <vector>
#include <map>

using namespace std;

Compiler::Compiler(char **argv) // constructor
{
    sourceFile.open(argv[1]);
    listingFile.open(argv[2]);
    objectFile.open(argv[3]);
}

Compiler::~Compiler()           // destructor
{
    sourceFile.close();
    listingFile.close();
    objectFile.close();
}

void Compiler::createListingHeader()
{
    time_t now = time (NULL);
    listingFile << "STAGE0: Zachary German & Christian Matthews      "
         << ctime(&now) << "\nLINE NO.              SOURCE STATEMENT\n\n";
}

void Compiler::parser()///////////////////
{
    lineNo += 1;
    listingFile << setw(5) << right << lineNo << "|";
    nextChar();
    //ch must be initialized to the first character of the source file
    if (nextToken() != "program"){
        processError("keyword \"program\" expected");
    }
    //a call to nextToken() has two effects
    //  (1) the variable, token, is assigned the value of the next token
    //  (2) the next token is read from the source file in order to make
    //      the assignment. The value returned by nextToken() is also
    //      the next token.

    prog();
    //parser implements the grammar rules, calling first rule
}

void Compiler::createListingTrailer()
{
    if (errorCount == 1){
        listingFile << endl << left << "COMPILATION TERMINATED " << right << setw(6) << errorCount << " ERROR ENCOUNTERED" << endl;
    }
    else {
        listingFile << endl << left << "COMPILATION TERMINATED " << right << setw(6) << errorCount << " ERRORS ENCOUNTERED" << endl;
    }
    exit(0);
}

// Methods implementing the grammar productions

void Compiler::prog() //token should be "program"          // stage 0, production 1
{
    if (token != "program"){
        processError("keyword \"program\" expected *SYNTACTIC*");
    }
    progStmt();
    if (token == "const"){
        consts();
    }
    if (token == "var"){
        vars();
    }
    if(token != "begin"){
        processError("keyword \"begin\" expected *SYNTACTIC*");
    }
    beginEndStmt();
    // const char casting to check for END_OF_FILE token
    if (*token.c_str() != END_OF_FILE){
        processError("no text may follow \"end\" *SYNTACTIC*");
    }
}

void Compiler::progStmt()  //token should be "program"  // stage 0, production 2
{
    string x, y;
    if (token != "program"){
        processError("keyword \"program\" expected *SYNTACTIC*");
    }
    x = nextToken();
    if (!(isNonKeyId(token))){
        processError("program name expected *SYNTACTIC*");
    }
    y = nextToken();
    if (y != ";"){
        processError("semicolon expected *SYNTACTIC*");
    }
    nextToken();
    code("program", x);
    insert(x,PROG_NAME,CONSTANT,x,NO,0);
    // cout << "Int Name: " << x << "     Data Type: " << "PROG_NAME" << "     Mode: " << "CONSTANT" << "     Value:"
    //     << x << "     Alloc: "<< "NO" << "     Units:" << "0" << endl;
}

void Compiler::consts()    //token should be "const"     // stage 0, production 3
{
    if (token != "const"){
        processError("keyword \"const\" expected");
    }
    if (!(isNonKeyId(nextToken()))){
        processError("non-keyword identifier must follow \"const\"");
    }
    constStmts();
}

void Compiler::vars()    //token should be "var"       // stage 0, production 4
{
    if (token != "var"){
        processError("keyword \"var\" expected *SYNTACTIC*");
    }
    if (!(isNonKeyId(nextToken()))){
        processError("non-keyword identifier must follow \"var\" *SYNTACTIC*");
    }
    varStmts();
}

void Compiler::beginEndStmt()  //token should be "begin"       // stage 0, production 5
{
    if (token != "begin"){
        processError("keyword \"begin\" expected *SYNTACTIC*");
    }
    if (nextToken() != "end"){
        processError("keyword \"end\" expected *SYNTACTIC*");
    }
    if (nextToken() != "."){
        processError("period expected *SYNTACTIC*");
    }
    nextToken();
    code("end", ".");
}

void Compiler::constStmts()   //token should be NON_KEY_ID  // stage 0, production 6
{
    string x,y;
    if (!(isNonKeyId(token))){
        processError("non-keyword identifier expected *SYNTACTIC*");
    }
    x = token;
    if (nextToken() != "="){
        listingFile << "token for = expected : " << token;
        processError("\"=\" expected *SYNTACTIC*");
    }
    y = nextToken();
    if (y != "+" && y != "-" && y != "not"
        && !isNonKeyId(y) && !isBoolean(y) && !isInteger(y)){

        processError("token to right of \"=\" illegal *SYNTACTIC*");
    }
    if (y == "+" || y == "-"){
        if (!(isInteger(nextToken()))){
            processError("integer expected after sign *SYNTACTIC*");
        }
        y = y + token;
    }
    if (y == "not"){
        if (!(isBoolean(nextToken()))){
            processError("boolean expected after \"not\" *SYNTACTIC*");
        }
        if (token == "true"){
            y = "false";
        }
        else{
            y = "true";
        }
    }
    if (nextToken() != ";"){
        processError("semicolon expected *SYNTACTIC*");
    }
    if (whichType(y) != INTEGER && whichType(y) != BOOLEAN){
        processError("data type of token on the right-hand side must be INTEGER or BOOLEAN *SYNTACTIC*");
    }
    insert(x,whichType(y),CONSTANT,whichValue(y),YES,1);
    // cout << "Int Name: " << x << "     Data Type: " << whichType(y) << "     Mode: " << "CONSTANT" << "     Value:"
    //     << whichValue(y) << "     Alloc: "<< "YES" << "     Units:" << "1" << endl;
    x = nextToken();
    if (x != "begin" && x != "var" && !(isNonKeyId(x))){
        processError("non-keyword identifier, \"begin\", or \"var\" expected *SYNTACTIC*");
    }
    if (isNonKeyId(x)){
        constStmts();
    }
}

void Compiler::varStmts()  //token should be NON_KEY_ID     // stage 0, production 7
{
    string x,y;
    storeTypes yType;
    if (!(isNonKeyId(token))){
        processError("non-keyword identifier expected *SYNTACTIC*");
    }
    x = ids();
    if (token != ":"){
        processError("\":\" expected");
    }
    if (nextToken() != "integer" && token != "boolean"){
        processError("illegal type follows \":\" *SYNTACTIC*");
    }
    if (token == "integer"){
        yType = INTEGER;
    }
    else {
        yType = BOOLEAN;
    }
    if (nextToken() != ";"){
        processError("semicolon expected *SYNTACTIC*");
    }
    insert(x,yType,VARIABLE,"",YES,1);
    // cout << "Int Name:" << x << "     Data Type: " << yType << "     Mode: " << "VARIABLE" << "     Value:"
    //     << "n/a" << "     Alloc: "<< "YES" << "     Units:" << "1" << endl;

    if (nextToken() != "begin" && !(isNonKeyId(token))){
        processError("non-keyword identifier or \"begin\" expected *SYNTACTIC*");
    }
    if (isNonKeyId(token)){
        varStmts();
    }
    else {
        return;
    }
}

string Compiler::ids()    //token should be NON_KEY_ID      // stage 0, production 8
{
    static string tempCheck;
    string temp,tempString;
    if (!(isNonKeyId(token))){
        processError("non-keyword identifier expected *SYNTACTIC*");
    }
    tempString = token;
    temp = token;
    if (nextToken() == ","){
        if (!(isNonKeyId(nextToken()))){
            processError("non-keyword identifier expected *SYNTACTIC*");
        }
        if (tempCheck.find(","+token+",")){
            processError("multiple name definition");
        }
        tempCheck = tempCheck + "," + token + ",";
        tempString = temp + "," + ids();
    }
    tempCheck = "";
    return tempString;
}

// ***Stage 1 productions***

void Compiler::execStmts(){

}

void Compiler::execStmt(){

} 
void Compiler::assignStmt(){

} 

void Compiler::readStmt(){

}

void Compiler::writeStmt(){

}

void Compiler::express(){

}

void Compiler::expresses(){

}

void Compiler::term(){

}

void Compiler::terms(){

}

void Compiler::factor(){

}

void Compiler::factors(){

}

void Compiler::part(){

}  

// Helper functions for the Pascallite lexicon

bool Compiler::isKeyword(string s) const  // determines if s is a keyword
{
    const string keywordList[] = {"program","begin","end","var","const","integer","boolean","true","false","not"};
    for (string keyword : keywordList){
        if (keyword == s){
            return true;
        }
    }
    return false;
}

bool Compiler::isSpecialSymbol(char c) const // determines if c is a special symbol
{
    const char specSymList[] = {'=',':',',',';','.','+','-'};
    for (char specSym : specSymList){
        if (specSym == c){
            return true;
        }
    }
    return false;
}

bool Compiler::isNonKeyId(string s) const // determines if s is a non_key_id
{
    //Is (s) a keyword?
    if (isKeyword(s)){
        return false;
    }
    bool startsWithAlpha = 0;
    const char alphaList[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    const char alphaNumsList[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0','_'};
    for (string::size_type i = 0; i < s.size(); i++){
        //Does it start with a lowercase letter?
        if (i == 0){
            for (char alpha : alphaList){
                if (s[i] == alpha){
                    startsWithAlpha = 1;
                }
            }
            if (startsWithAlpha == 0){
                return false;
            }
        }
        //Does the rest consist of letters, numbers, and '_'?
        bool valid = 0;
        for (char listChar : alphaNumsList){
            if (s[i] == listChar){
                valid = 1;
            }
        }
        if (!valid){
            return false;
        }
        //Does it end in an underscore ('_')
        if (i+1 == s.size() && s[i] == '_'){
            return false;
        }
    }
    return true;
}

bool Compiler::isInteger(string s) const  // determines if s is an integer
{
    try {stoi(s);}
    catch (const invalid_argument& ia){
        return false;
    }
    return true;
}

bool Compiler::isBoolean(string s) const  // determines if s is a boolean
{
    if (s == "true" || s == "false"){
        return true;
    }
    return false;
}

bool Compiler::isLiteral(string s) const  // determines if s is a literal
{
    // if s is integer
    if (isInteger(s)) {
        return true;
    }
    // if s starts with "+" or "-" AND is an integer
    if ((s[0] == '+' || s[0] == '-') && isInteger(s.substr(1,(s.length()-1)))) {
        return true;
    }
    // if s is boolean
    if (isBoolean(s)) {
        return true;
    }
    // if s = "not" AND is a boolean
    if (s == "not") {
        return true;
    }
    return false;
}

// Action routines

void Compiler::insert(string externalName, storeTypes inType, modes inMode,
                      string inValue, allocation inAlloc, int inUnits)
{
    deque<string> nameList;
    int strStart = 0;
    static int entryCount = 0;
    string type;
    string mode;
    string alloc;

    if (inType == BOOLEAN) {
        type = "BOOLEAN";
    } else if (inType == INTEGER) {
        type = "INTEGER";
    } else if (inType == PROG_NAME) {
        type = "PROG_NAME";
    }

    if (inMode == CONSTANT) {
        mode = "CONSTANT";
    } else if (inMode == VARIABLE) {
        mode = "VARIABLE";
    }

    if (inAlloc == YES) {
        alloc = "YES";
    } else if (inAlloc == NO) {
        alloc = "NO";
    }



    for (unsigned int i = 0; i < externalName.length(); i++){
        if (externalName[i] == ','){
            nameList.push_back(externalName.substr(strStart,i-strStart));
            strStart = i+1;
        }
        if (i == externalName.length() - 1){
            nameList.push_back(externalName.substr(strStart));
        }
    }
    while (!nameList.empty()){
        string name = nameList.front();
        nameList.pop_front();
        if (symbolTable.count(name)){     //returns 1 if entry with 'name' key exists, 0 otherwise
            processError("symbol " + name + " is multiply defined *SEMANTIC*");
        }
        else if (isKeyword(name)){
            processError("illegal use of keyword *SEMANTIC*");
        }
        else { //create table entry     
            if (isupper(name[0])){
                if (entryCount >= 256){
                    processError("symbolTable limit of 256 entries exceeded *SEMANTIC*");
                }
                symbolTable.insert({name,SymbolTableEntry(name,inType,inMode,inValue,inAlloc,inUnits)});
                cout << "Int Name:" << name << "     Data Type: " << type << "     Mode: " << mode << "     Value:"
                        << "inValue" << "     Alloc: "<< alloc << "     Units:" << inUnits << endl;
                entryCount += 1;
            }
            else {
                if (entryCount >= 256){
                    processError("symbolTable limit of 256 entries exceeded *SEMANTIC*");
                }
                string genName = genInternalName(inType);
                symbolTable.insert({name,SymbolTableEntry(genName,inType,inMode,inValue,inAlloc,inUnits)});
                cout << "Int Name:" << genName << "     Data Type: " << type << "     Mode: " << mode << "     Value:"
                        << inValue << "     Alloc: "<< alloc << "     Units:" << inUnits << endl;
                entryCount += 1;
            }
        }
    }
}

storeTypes Compiler::whichType(string name) // tells which data type a name has
{
    bool flaggy = 0;
    storeTypes dataType;
    if (isLiteral(name)){
        if (isBoolean(name)){
            return BOOLEAN;
        }
        else {
            return INTEGER;
        }
    }
    else { // name is an identifier and hopefully a constant
        for (auto const& [internalName, tableEntry] : symbolTable){
            if (internalName == name){
                dataType = tableEntry.getDataType();
                flaggy = 1;
            }
        }
        if (flaggy == 0){
            processError("reference to undefined constant whichType(string name) *SEMANTIC*");                          // You left off here !!!
        }
    }
    return dataType;
}

string Compiler::whichValue(string name) // tells which value a name has
{
    bool flaggy = 0;
    string value;
    if (isLiteral(name)){
        if (name == "true"){
            value = "-1";
        }
        else if (name == "false"){
            value = "0";
        }
        else {
            value = name;
        }
    }
    else { // name is an identifier and hopefully a constant
        for (auto const& [internalName, tableEntry] : symbolTable){
            if (internalName == name){
                value = tableEntry.getValue();
                flaggy = 1;
            }
        }
        if (flaggy == 0){
            processError("reference to undefined constant whichval *SEMANTIC*");
        }
    }
    return value;
}

void Compiler::code(string op, string operand1/* = ""*/, string operand2/* = ""*/)
{
    if (op == "program"){
        emitPrologue(operand1);
    }
    else if (op == "end"){
        emitEpilogue();
    }
    else {
        processError("compiler error since function code should not be called with illegal arguments *SEMANTIC*");
    }
}
// *** Stage 1 action routines***

void Compiler::pushOperator(string op){
    //push name onto stack
}

string Compiler::popOperator(){     //pop name from operatorStk
    //if operatorStk is not empty
    //      return top element removed from stack
    //else
    //      processError(compiler error; operator stack underflow) 
}

void Compiler::pushOperand(string operand){          //if name is a literal, also create a symbol table entry for it 
    //if name is a literal and has no symbol table entry
    //      insert symbol table entry, call whichType to determine the data type of the literal 
    //push name onto stack;
}

string Compiler::popOperand(){      //pop name from operandStk 
    //if operandStk is not empty
    //      return top element removed from stack
    //else
    //      processError(compiler error; operand stack underflow)
}

// Emit Functions

void Compiler::emit(string label/* = ""*/, string instruction/* = ""*/, 
                    string operands/* = ""*/, string comment/* = ""*/)
{
    if (comment == ""){
    objectFile << left << setw(8) << label << setw(8) << instruction << setw(24) << operands << comment << endl;
    }
    else {
    objectFile << left << setw(8) << label << setw(8) << instruction << setw(24) << operands << "; " << comment << endl;
    }
    // Turn on left justification in objectFile
    // Output label in a field of width 8
    // Output instruction in a field of width 8
    // Output the operands in a field of width 24
    // Output the comment
}

void Compiler::emitPrologue(string progName, string operand2/* = ""*/)
{
    time_t now = time (NULL);
    objectFile << "; Zachary German & Cristian Matthews      " << ctime(&now);
    objectFile << "%INCLUDE \"Along32.inc\"" << endl << "%INCLUDE \"Macros_Along.inc\"" << endl << endl;
    emit("SECTION", ".text");
    emit("global", "_start", "", "program " + progName);
    objectFile << endl;
    emit("_start:");
}

void Compiler::emitEpilogue(string operand1, string operand2)
{
    emit("","Exit", "{0}");
    emitStorage();
}

void Compiler::emitStorage()
{
    objectFile << endl;
    emit("SECTION", ".data");
    for (const auto &entry : symbolTable){
        if (entry.second.getAlloc() == YES && entry.second.getMode() == CONSTANT){
            string InternalName = entry.second.getInternalName();
            emit(InternalName, "dd", entry.second.getValue(), entry.first);
        }
    } 
    // for those entries in the symbolTable that 
    // have an allocation of YES and a storage mode of CONSTANT
    // { call emit to output a line to objectFile }
    objectFile << endl;
    emit("SECTION", ".bss");
    for (const auto &entry : symbolTable){
        if (entry.second.getAlloc() == YES && entry.second.getMode() == VARIABLE){
            string InternalName = entry.second.getInternalName();
            emit(InternalName, "resd", "1", entry.first);
        }
    } 
    // for those entries in the symbolTable that
    // have an allocation of YES and a storage mode of VARIABLE
    // { call emit to output a line to objectFile }    
}

// *** Stage 1 emit functions

void Compiler::emitAssignCode(string operand1, string operand2){

}

void Compiler::emitAdditionCode(string operand1, string operand2){      //add operand1 to operand2
    //if type of either operand is not integer
    //      process error(illegal type)
    //if A Register holds a temp not operand1 nor operand2 then
    //      emit code to store that temp into memory
    //      change the allocate entry for the temp in the symbol table to yes
    //      deassign it
    //if A register holds a non-temp not operand1 nor operand2 then deassign it
    //if neither operand is in A register then
    //      emit code to load operand2 into A register
    //emit code to perform register-memory addition
    //deassign all temporaries involved in the addition and free those names for reuse
    //A Register = next available temporary name and change type of its symbol table entry to integer
    //push the name of the result onto operandStk
}

void Compiler::emitSubtractionCode(string operand1, string operand2){       //
    //if type of either operand is not integer
    //      process error(illegal type) 
    //if A Register holds a temp not operand1 nor operand2 then 
    //      emit code to store that temp into memory
    //      change the allocate entry for the temp in the symbol table to yes
    //      deassign it
    //if A register holds a non-temp not operand1 nor operand2 then deassign it
    //if neither operand is in A register then
    //      emit code to load operand2 into A register
    //emit code to perform register-memory addition
    //deassign all temporaries involved in the addition and free those names for reuse
    //A Register = next available temporary name and change type of its symbol table entry to integer
    //push the name of the result onto operandStk
}

void Compiler::emitMultiplicationCode(string operand1, string operand2){

}

void Compiler::emitDivisionCode(string operand1, string operand2){

}

void Compiler::emitModuloCode(string operand1, string operand2){

}

void Compiler::emitNegationCode(string operand1, string = ""){

}

void Compiler::emitNotCode(string operand1, string = ""){

}

void Compiler::emitAndCode(string operand1, string operand2){

}

void Compiler::emitOrCode(string operand1, string operand2){

}

void Compiler::emitEqualityCode(string operand1, string operand2){

}

void Compiler::emitInequalityCode(string operand1, string operand2){

}

void Compiler::emitLessThanCode(string operand1, string operand2){

}

void Compiler::emitLessThanOrEqualToCode(string operand1, string operand2){

}

void Compiler::emitGreaterThanCode(string operand1, string operand2){

}

void Compiler::emitGreaterThanOrEqualToCode(string operand1, string operand2){

}

// Lexical routines

char Compiler::nextChar() // returns the next character or END_OF_FILE marker
{
    sourceFile.get(ch);
    if (sourceFile.eof()){
        ch = END_OF_FILE; // use a special char to designate end of file
    }
    //print to listing file (starting new line if necessary)
    if (ch == '\n' && sourceFile.peek() != EOF){
        lineNo += 1;
        listingFile << endl;
        listingFile << setw(5) << right << lineNo << "|";
    }
    else if (ch != END_OF_FILE){
        listingFile << ch;
    }
    else {
        return ch;
    }
    return ch;
}

string Compiler::nextToken() // returns the next token or END_OF_FILE marker
{
    token = "";
    int charCount = 0;
    while (token == ""){
        if (ch == '{') {
            while (nextChar() != END_OF_FILE && ch != '}') {
            }
            if (ch == END_OF_FILE){
                processError("unexpected END_OF_FILE marker *LEXICAL*");
            }
            else {
                nextChar();
            }
        } else if (ch == '}') {
            processError("'}' cannot begin token *LEXICAL*");
        } else if (isspace(ch)) {
            nextChar();
        } else if (isSpecialSymbol(ch)) {
            token = ch;
            nextChar();
        } else if (islower(ch)) {
            charCount += 1;
            token = ch;
            while ((isalpha(nextChar()) || isdigit(ch) || ch == '_') && ch != END_OF_FILE) {
                if (charCount < 15){
                    token += ch;
                    charCount += 1;
                }
            }
            if(ch == END_OF_FILE) {
                processError("unexpected END_OF_FILE marker *LEXICAL*");
            }
        } else if (isdigit(ch)) {
            token = ch;
            while (isdigit(nextChar()) && ch != END_OF_FILE){
                token += ch;
            }
            if (ch == END_OF_FILE){
                processError("unexpected end of file *LEXICAL*");
            }
        } else if (ch == END_OF_FILE) {
            token = ch;
        } else {
            processError("illegal symbol *LEXICAL*");
        }
    }
    return token;
}

// Other routines

string Compiler::genInternalName(storeTypes stype) const
{
    static int iCnt, bCnt, pCnt = 0;
    string name;
    if (stype == INTEGER){
        name = "I";
        name = name + to_string(iCnt);
        iCnt += 1;
    }
    else if (stype == BOOLEAN){
        name = "B";
        name = name + to_string(bCnt);
        bCnt += 1;
    }
    else /*(stype == PROG_NAME)*/{
        name = "P";
        name = name + to_string(pCnt);
        pCnt += 1;
    }
    return name;
}

void Compiler::processError(string err)
{
    listingFile << endl << "Error: Line " << lineNo << ": " << err << endl;
    errorCount += 1;
    createListingTrailer();
}

// ***Stage 1 other routines***
void Compiler::freeTemp(){

}

string Compiler::getTemp(){

}

string Compiler::getLabel(){

}

bool Compiler::isTemporary(string s) const{
    
}
